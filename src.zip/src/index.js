'use strict';

// Entry orchestrator if we expand beyond storage migration
require('./migrate_storage');


